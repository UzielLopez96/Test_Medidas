﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversion
{
    public partial class Pagina2 : Form
    {
        public Pagina2()
        {
            InitializeComponent();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            pagina1 pagina = new pagina1();
            pagina.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pagina3 pag3 = new Pagina3();
            pag3.Show();
            this.Hide();
        }

        private void btnConfirma_Click(object sender, EventArgs e)
        {
            resultados Respuesta = new resultados();
            if (c1Button.Checked)
            {
                Respuesta.b = 2;
            }
            else
            {
                Respuesta.b = 0;
            }
            MessageBox.Show($"Obtienes {Respuesta.b} puntos");
        }
    }
}
