﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversion
{
    public partial class Pagina4 : Form
    {
        public Pagina4()
        {
            InitializeComponent();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            Pagina3 pag3 = new Pagina3();
            pag3.Show();
            this.Hide();
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            Pagina5 pag5 = new Pagina5();
            pag5.Show(); 
            this.Hide();
        }

        private void btnConfirma_Click(object sender, EventArgs e)
        {
            resultados Respuesta = new resultados();
            if (c1Button.Checked)
            {
                Respuesta.d = 2;
            }
            else
            {
                Respuesta.d = 0;
            }
            MessageBox.Show($"Obtienes {Respuesta.d} puntos");
        }
    }
}
