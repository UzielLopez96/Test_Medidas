﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversion
{
    public partial class Pagina5 : Form
    {

        public Pagina5()
        {
            InitializeComponent();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            Pagina4 pag4 = new Pagina4();
            pag4.Show();
            this.Hide();
        }

        private void btnConfirma_Click(object sender, EventArgs e)
        {
            resultados Respuesta = new resultados();
            if (c1Button.Checked)
            {
                Respuesta.e = 2;
            }
            else
            {
                Respuesta.e = 0;
            }
            MessageBox.Show($"Obtienes {Respuesta.e} puntos");
        }

        private void btnFin_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
