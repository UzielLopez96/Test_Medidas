﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conversion
{
    public class resultados
    {
        public int a { get; set; } 
        public int b { get; set; }
        public int c { get; set; }
        public int d { get; set; }
        public int e { get; set; }

    }
}
