﻿namespace conversion
{
    partial class Pagina4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAtras = new System.Windows.Forms.Button();
            this.btnConfirma = new System.Windows.Forms.Button();
            this.i2Button = new System.Windows.Forms.RadioButton();
            this.i1Button = new System.Windows.Forms.RadioButton();
            this.c1Button = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAtras
            // 
            this.btnAtras.Location = new System.Drawing.Point(55, 268);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(75, 23);
            this.btnAtras.TabIndex = 25;
            this.btnAtras.Text = "Atras";
            this.btnAtras.UseVisualStyleBackColor = true;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // btnConfirma
            // 
            this.btnConfirma.Location = new System.Drawing.Point(237, 268);
            this.btnConfirma.Name = "btnConfirma";
            this.btnConfirma.Size = new System.Drawing.Size(83, 23);
            this.btnConfirma.TabIndex = 24;
            this.btnConfirma.Text = "Confitmar";
            this.btnConfirma.UseVisualStyleBackColor = true;
            this.btnConfirma.Click += new System.EventHandler(this.btnConfirma_Click);
            // 
            // i2Button
            // 
            this.i2Button.AutoSize = true;
            this.i2Button.Location = new System.Drawing.Point(437, 170);
            this.i2Button.Name = "i2Button";
            this.i2Button.Size = new System.Drawing.Size(105, 20);
            this.i2Button.TabIndex = 23;
            this.i2Button.TabStop = true;
            this.i2Button.Text = "2x10^5 dm^2";
            this.i2Button.UseVisualStyleBackColor = true;
            // 
            // i1Button
            // 
            this.i1Button.AutoSize = true;
            this.i1Button.Location = new System.Drawing.Point(237, 170);
            this.i1Button.Name = "i1Button";
            this.i1Button.Size = new System.Drawing.Size(105, 20);
            this.i1Button.TabIndex = 22;
            this.i1Button.TabStop = true;
            this.i1Button.Text = "2x10^4 dm^2";
            this.i1Button.UseVisualStyleBackColor = true;
            // 
            // c1Button
            // 
            this.c1Button.AutoSize = true;
            this.c1Button.Location = new System.Drawing.Point(55, 170);
            this.c1Button.Name = "c1Button";
            this.c1Button.Size = new System.Drawing.Size(105, 20);
            this.c1Button.TabIndex = 21;
            this.c1Button.TabStop = true;
            this.c1Button.Text = "2x10^6 dm^2";
            this.c1Button.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Opciones";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "200 dam^2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "4.- Escribir la siguiente área en decímetros cuadrados:";
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.Location = new System.Drawing.Point(440, 268);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(75, 23);
            this.btnSiguiente.TabIndex = 17;
            this.btnSiguiente.Text = "Siguiente";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // Pagina4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 324);
            this.Controls.Add(this.btnAtras);
            this.Controls.Add(this.btnConfirma);
            this.Controls.Add(this.i2Button);
            this.Controls.Add(this.i1Button);
            this.Controls.Add(this.c1Button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSiguiente);
            this.Name = "Pagina4";
            this.Text = "Pagina4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAtras;
        private System.Windows.Forms.Button btnConfirma;
        private System.Windows.Forms.RadioButton i2Button;
        private System.Windows.Forms.RadioButton i1Button;
        private System.Windows.Forms.RadioButton c1Button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSiguiente;
    }
}