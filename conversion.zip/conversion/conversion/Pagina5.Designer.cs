﻿namespace conversion
{
    partial class Pagina5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAtras = new System.Windows.Forms.Button();
            this.btnConfirma = new System.Windows.Forms.Button();
            this.i2Button = new System.Windows.Forms.RadioButton();
            this.i1Button = new System.Windows.Forms.RadioButton();
            this.c1Button = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAtras
            // 
            this.btnAtras.Location = new System.Drawing.Point(48, 262);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(75, 23);
            this.btnAtras.TabIndex = 34;
            this.btnAtras.Text = "Atras";
            this.btnAtras.UseVisualStyleBackColor = true;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // btnConfirma
            // 
            this.btnConfirma.Location = new System.Drawing.Point(230, 262);
            this.btnConfirma.Name = "btnConfirma";
            this.btnConfirma.Size = new System.Drawing.Size(83, 23);
            this.btnConfirma.TabIndex = 33;
            this.btnConfirma.Text = "Confitmar";
            this.btnConfirma.UseVisualStyleBackColor = true;
            this.btnConfirma.Click += new System.EventHandler(this.btnConfirma_Click);
            // 
            // i2Button
            // 
            this.i2Button.AutoSize = true;
            this.i2Button.Location = new System.Drawing.Point(48, 164);
            this.i2Button.Name = "i2Button";
            this.i2Button.Size = new System.Drawing.Size(80, 20);
            this.i2Button.TabIndex = 32;
            this.i2Button.TabStop = true;
            this.i2Button.Text = "441000 L";
            this.i2Button.UseVisualStyleBackColor = true;
            // 
            // i1Button
            // 
            this.i1Button.AutoSize = true;
            this.i1Button.Location = new System.Drawing.Point(230, 164);
            this.i1Button.Name = "i1Button";
            this.i1Button.Size = new System.Drawing.Size(80, 20);
            this.i1Button.TabIndex = 31;
            this.i1Button.TabStop = true;
            this.i1Button.Text = "444000 L";
            this.i1Button.UseVisualStyleBackColor = true;
            // 
            // c1Button
            // 
            this.c1Button.AutoSize = true;
            this.c1Button.Location = new System.Drawing.Point(412, 164);
            this.c1Button.Name = "c1Button";
            this.c1Button.Size = new System.Drawing.Size(80, 20);
            this.c1Button.TabIndex = 30;
            this.c1Button.TabStop = true;
            this.c1Button.Text = "414000 L";
            this.c1Button.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 29;
            this.label3.Text = "Opciones";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(496, 16);
            this.label1.TabIndex = 27;
            this.label1.Text = "5.- Calcular cuántos litros de agua caben en una piscina de dimensiones 3x6x23 m." +
    "";
            // 
            // btnFin
            // 
            this.btnFin.Location = new System.Drawing.Point(433, 262);
            this.btnFin.Name = "btnFin";
            this.btnFin.Size = new System.Drawing.Size(75, 23);
            this.btnFin.TabIndex = 26;
            this.btnFin.Text = "Terminar";
            this.btnFin.UseVisualStyleBackColor = true;
            this.btnFin.Click += new System.EventHandler(this.btnFin_Click);
            // 
            // Pagina5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 326);
            this.Controls.Add(this.btnAtras);
            this.Controls.Add(this.btnConfirma);
            this.Controls.Add(this.i2Button);
            this.Controls.Add(this.i1Button);
            this.Controls.Add(this.c1Button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFin);
            this.Name = "Pagina5";
            this.Text = "Pagina5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAtras;
        private System.Windows.Forms.Button btnConfirma;
        private System.Windows.Forms.RadioButton i2Button;
        private System.Windows.Forms.RadioButton i1Button;
        private System.Windows.Forms.RadioButton c1Button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFin;
    }
}