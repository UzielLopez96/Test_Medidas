﻿namespace conversion
{
    partial class pagina1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.c1Button = new System.Windows.Forms.RadioButton();
            this.i1Button = new System.Windows.Forms.RadioButton();
            this.i2Button = new System.Windows.Forms.RadioButton();
            this.btnConfirma = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.Location = new System.Drawing.Point(498, 253);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(75, 23);
            this.btnSiguiente.TabIndex = 0;
            this.btnSiguiente.Text = "Siguiente";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(559, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "1.-Escribir la siguiente área en kilómetros cuadrados multiplicando o dividiendo " +
    "sólo una vez:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "0.12hm^2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Opciones";
            // 
            // c1Button
            // 
            this.c1Button.AutoSize = true;
            this.c1Button.Location = new System.Drawing.Point(223, 155);
            this.c1Button.Name = "c1Button";
            this.c1Button.Size = new System.Drawing.Size(118, 20);
            this.c1Button.TabIndex = 4;
            this.c1Button.TabStop = true;
            this.c1Button.Text = "12x10 ^-4 km^2";
            this.c1Button.UseVisualStyleBackColor = true;
            this.c1Button.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // i1Button
            // 
            this.i1Button.AutoSize = true;
            this.i1Button.Location = new System.Drawing.Point(41, 155);
            this.i1Button.Name = "i1Button";
            this.i1Button.Size = new System.Drawing.Size(111, 20);
            this.i1Button.TabIndex = 5;
            this.i1Button.TabStop = true;
            this.i1Button.Text = "12x8 ^-4 km^2";
            this.i1Button.UseVisualStyleBackColor = true;
            // 
            // i2Button
            // 
            this.i2Button.AutoSize = true;
            this.i2Button.Location = new System.Drawing.Point(423, 155);
            this.i2Button.Name = "i2Button";
            this.i2Button.Size = new System.Drawing.Size(111, 20);
            this.i2Button.TabIndex = 6;
            this.i2Button.TabStop = true;
            this.i2Button.Text = "8x10 ^-4 km^2";
            this.i2Button.UseVisualStyleBackColor = true;
            // 
            // btnConfirma
            // 
            this.btnConfirma.Location = new System.Drawing.Point(41, 253);
            this.btnConfirma.Name = "btnConfirma";
            this.btnConfirma.Size = new System.Drawing.Size(75, 23);
            this.btnConfirma.TabIndex = 7;
            this.btnConfirma.Text = "Confirmar";
            this.btnConfirma.UseVisualStyleBackColor = true;
            this.btnConfirma.Click += new System.EventHandler(this.btnConfirma_Click);
            // 
            // pagina1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 288);
            this.Controls.Add(this.btnConfirma);
            this.Controls.Add(this.i2Button);
            this.Controls.Add(this.i1Button);
            this.Controls.Add(this.c1Button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSiguiente);
            this.Name = "pagina1";
            this.Text = "pagina1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton c1Button;
        private System.Windows.Forms.RadioButton i1Button;
        private System.Windows.Forms.RadioButton i2Button;
        private System.Windows.Forms.Button btnConfirma;
    }
}