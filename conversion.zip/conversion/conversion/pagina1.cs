﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversion
{
    public partial class pagina1 : Form
    {
        public pagina1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pagina2 pag2 = new Pagina2();
            pag2.Show();
            this.Hide();
        }

        private void btnConfirma_Click(object sender, EventArgs e)
        {
            resultados Respuesta = new resultados();
            if (c1Button.Checked)
            {
                Respuesta.a = 2;
            } else
            {
                Respuesta.a = 0;
            }
            MessageBox.Show($"Obtienes {Respuesta.a} puntos");
        }
    }
}
